package org.cap.demo.controller;

import java.util.List;

import org.cap.model.Pilot;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
	@RequestMapping("/hello")
	public ModelAndView sayHello() {
		String message="Hi Shivani. Good Morning..!!";
		return new ModelAndView("helloPage","msg",message);
	}
	
	@RequestMapping("/Login")
	public String validateLogin(ModelMap map, @RequestParam("username")String username, @RequestParam("password")String password) {
		if(username.equals("shivani") && password.equals("shivani123")) {
			map.put("pilot", new Pilot());
			return "pilotForm";
		}
		return "redirect:/";
}
}
