package org.cap.demo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(JavaConfig.class);
		Employee employee=(Employee) context.getBean(Employee.class);
		Employee employee1=(Employee) context.getBean(Employee.class);
		Student stud=(Student) context.getBean(Student.class);
		
		employee1.setEmployeeName("Mayuri");
		System.out.println(employee);
		System.out.println(employee1);
		System.out.println(stud);
		
		context.registerShutdownHook();

	}

}
