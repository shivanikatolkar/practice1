package org.cap.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
//import org.springframework.context.annotation.Scope;

@Import({MyConfig.class})
@Configuration
public class JavaConfig {
	@Bean
	//@Scope("prototype")
	public Employee getEmployee() {
		Employee emp=new Employee();
		emp.setEmployeeId(1001);
		emp.setEmployeeName("Shivani");
		emp.setSalary(10000);
		emp.setAge(23);
		return emp;
	}
	@Bean
	public Address getAddress() {
		Address addr=new Address();
		addr.setDoorNo("86");
		addr.setStName("Swavalambi Nagar");
		addr.setCity("Nagpur");
		return addr;
	}
	
	@Bean
	public Address getAddress1() {
		Address addr=new Address();
		addr.setDoorNo("98");
		addr.setStName("Narendra Nagar");
		addr.setCity("Nagpur");
		return addr;
	}
}

