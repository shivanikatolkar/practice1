package org.cap.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;


@Configuration
public class MyConfig {

		@Bean
		public Student getStud() {
			Student s=new Student();
			s.setStudentId(100);
			s.setStudentName("Kalyani");
			return s;
		}
		
}
