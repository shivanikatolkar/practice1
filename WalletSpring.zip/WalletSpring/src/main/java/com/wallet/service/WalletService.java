package com.wallet.service;

public interface WalletService {
	
}
