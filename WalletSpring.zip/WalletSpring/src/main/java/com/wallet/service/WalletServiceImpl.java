package com.wallet.service;

public class WalletServiceImpl implements WalletService {


}
