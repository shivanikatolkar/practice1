package com.wallet.dao;


public class WalletDaoImpl implements WalletDao {
	
}
