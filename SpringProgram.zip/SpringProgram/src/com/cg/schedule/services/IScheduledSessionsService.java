package com.cg.schedule.services;

import java.util.List;

import com.cg.schedule.beans.ScheduledSessions;
import com.cg.schedule.exceptions.ScheduledSessionsException;

public interface IScheduledSessionsService {
	List<ScheduledSessions> viewSessions() throws ScheduledSessionsException;
}
