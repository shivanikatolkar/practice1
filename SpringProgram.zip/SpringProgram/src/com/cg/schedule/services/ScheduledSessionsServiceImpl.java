package com.cg.schedule.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.schedule.beans.ScheduledSessions;
import com.cg.schedule.dao.IScheduledSessionsDAO;
import com.cg.schedule.exceptions.ScheduledSessionsException;

@Component(value="service")
public class ScheduledSessionsServiceImpl implements IScheduledSessionsService{

	@Autowired
	IScheduledSessionsDAO dao;//dao layer object to access all method from dao layer
	
	@Override
	public List<ScheduledSessions> viewSessions() throws ScheduledSessionsException {
		List<ScheduledSessions> list=dao.findAll();
		if(list!=null)
			return list;
		else//if no sessions are available then exceptions will print a message on home page.
			throw new ScheduledSessionsException("Sessions are not available!!");
	}

}
