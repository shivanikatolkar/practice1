package org.cap.dao;

import java.util.List;

import org.cap.model.Student;

public interface IStudentDao {

	public  List<Student> getStudents();
	public void update(Student student);
	public Student findStudent(Integer studentId);
}
