package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Student;
import org.springframework.stereotype.Repository;

@Repository("studentDao")
public class StudentDaoImpl implements IStudentDao {

	@PersistenceContext
	private EntityManager em;
	
	@Transactional
	@Override
	public List<Student> getStudents() {
		List<Student> students = em.createQuery("from Student").getResultList();
		return students;
	}
	
	@Transactional
	@Override
	public void update(Student student) {
		Student student1= em.find(Student.class, student.getStudId());
		if(student1==null)
			em.persist(student);
		else
			em.merge(student);
		
	}
	@Transactional
	@Override
	public Student findStudent(Integer studentId) {
		Student student= em.find(Student.class, studentId);
		return student;
	}

}
