package org.cap.service;

import java.util.List;
import org.cap.dao.PilotDaoInterface;
import org.cap.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("pilotDBService")
public class PilotServiceImpl implements PilotServiceInterface {

	@Autowired
	private PilotDaoInterface pilotDBdao;
	
	@Override
	public List<Pilot> getAllPilots() {
		
		return pilotDBdao.findAll();
	}
	@Override
	public Pilot findPilot(Integer pilotId) {
		return pilotDBdao.getOne(pilotId);
	}
	@Override
	public List<Pilot> deletePilot(Integer pilotId) {
		pilotDBdao.deleteById(pilotId);
		return pilotDBdao.findAll();
	}
	@Override
	public List<Pilot> createPilot(Pilot pilot) {
		pilotDBdao.save(pilot);
		return pilotDBdao.findAll();
	}
	@Override
	public List<Pilot> updatePilot(Pilot pilot) {
		pilotDBdao.save(pilot);
		return pilotDBdao.findAll();
	}
	@Override
	public void save(Pilot pilot) {
		pilotDBdao.save(pilot);
		
	}

}
