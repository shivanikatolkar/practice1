package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;

@Repository("pilotDbDao")
@Transactional
public class PilotDaoDBImpl implements IPilotDao {
	
	@PersistenceContext
	private EntityManager em;

	@Override
	public List<Pilot> getAllPilots() {
		List<Pilot> pilots=em.createQuery("from Pilot").getResultList();
		
		return pilots;
	}

	@Override
	public Pilot findPilot(Integer pilotId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Pilot> deletePilot(Integer pilotId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Pilot> createPilot(Pilot pilot) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Pilot> updatePilot(Pilot pilot) {
		// TODO Auto-generated method stub
		return null;
	}

}
