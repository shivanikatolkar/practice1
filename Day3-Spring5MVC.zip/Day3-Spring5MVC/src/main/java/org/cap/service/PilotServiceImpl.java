package org.cap.service;

import java.util.List;

import org.cap.dao.PilotDao;
import org.cap.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("pilotService")
public class PilotServiceImpl implements PilotService {
	@Autowired
	private PilotDao pilotDao;
	
	@Override
	public void save(Pilot pilot) {
		pilotDao.save(pilot);

	}

	@Override
	public List<Pilot> getAll() {
		return pilotDao.getAll();
	}

	@Override
	public void delete(Integer pilotId) {
		pilotDao.delete(pilotId);
		
	}

	@Override
	public void update(Pilot pilot) {
		pilotDao.update(pilot);
		
	}

	@Override
	public Pilot findPilot(Integer pilotId) {
		
		return pilotDao.findPilot(pilotId);
	}

}
