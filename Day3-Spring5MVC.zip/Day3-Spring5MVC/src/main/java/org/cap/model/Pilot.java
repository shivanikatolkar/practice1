package org.cap.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Future;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

@Entity
public class Pilot {
	
	@Id
	@GeneratedValue
	private int pilotId;
	@NotEmpty(message="**please enter first name")
	private String firstName;
	@NotEmpty(message="**please enter last name")
	private String lastName;
	private String email;
	@Past(message="**please enter past date")
	private Date dateOfBirth;
	@Future(message="**please enter future date")
	private Date dateOfJoining;
	private Boolean isCertified;
	@Range(min=10000,max=200000,message="Salary should be between 10000 and 200000")
	private double salary;
	public int getPilotId() {
		return pilotId;
	}
	public void setPilotId(int pilotId) {
		this.pilotId = pilotId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Date getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public Boolean getIsCertified() {
		return isCertified;
	}
	public void setIsCertified(Boolean isCertified) {
		this.isCertified = isCertified;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Override
	public String toString() {
		return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", dateOfBirth=" + dateOfBirth + ", dateOfJoining=" + dateOfJoining + ", isCertified=" + isCertified
				+ ", salary=" + salary + "]";
	}
	
	public Pilot(int pilotId, String firstName, String lastName, String email, Date dateOfBirth, Date dateOfJoining,
			Boolean isCertified, double salary) {
		super();
		this.pilotId = pilotId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.dateOfBirth = dateOfBirth;
		this.dateOfJoining = dateOfJoining;
		this.isCertified = isCertified;
		this.salary = salary;
	}
	public Pilot() {
		
	}
	
	

}
