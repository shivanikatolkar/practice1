package org.cap.annotation;

public @interface AnnotationClass {

}
