package org.cap.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		//AbstractApplicationContext context = new FileSystemXmlApplicationContext("D:\\Users\\skatolka\\Desktop\\demoBeans.xml");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("myBean.xml");
		Employee employee=(Employee) context.getBean("employee");
		
		Employee employee1=(Employee) context.getBean("employee");
		
		employee.setEmployeeName("Jack");
		System.out.println(employee);
		System.out.println(employee1);
		Employee employee_1=(Employee) context.getBean("employee1");
		System.out.println(employee_1);
		
		context.registerShutdownHook();

	}

}
